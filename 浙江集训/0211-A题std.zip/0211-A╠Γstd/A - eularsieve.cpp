# include <stdio.h>
# include <string.h>
# include <iostream>
# include <algorithm>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

const int M = 1e6 + 10;

int mod;

bool vis[M];
int p[M], pn, inv[M];
int h[M];

inline ll solve(int n, int m) {
  int res = 0;
  for (int i=1, lst=0; i<=n; i=lst+1) {
    lst = min(n/(n/i), m/(m/i));
    int t = h[lst] - h[i-1];
    if(t < 0) t += mod;
    res += 1ll * (n/i) * (m/i) % mod * t % mod;
    if(res >= mod) res -= mod;
  }
  return res % mod;
}

int main() {
  int Test, n, m; cin >> Test;
  while(Test --) {
  	memset(vis, 0, sizeof vis);
	pn = 0;
	
    cin >> n >> m >> mod;
    if(n>m) swap(n, m);
    
    inv[1] = 1; 
    for (int i=2; i<=n; ++i) inv[i] = 1ll * (mod-mod/i) * inv[mod%i] % mod;
    
    h[1] = 1;
    for (int i=2; i<=n; ++i) {
      if(!vis[i]) {
        p[++pn] = i;
        h[i] = inv[i-1];
      }
      for (int j=1; j<=pn && i*p[j]<=n; ++j) {
        vis[i*p[j]] = 1;
        if(i%p[j] == 0) {
		  h[i*p[j]] = 0;
		  break;
		} else h[i*p[j]] = 1ll * h[i] * h[p[j]] % mod;
      }
    }
    for (int i=1; i<=n; ++i) {
      h[i] += h[i-1];
      if(h[i] >= mod) h[i] -= mod;
    }
    cout << solve(n, m) << endl;
  }
    
  return 0;
}
