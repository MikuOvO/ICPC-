# include <stdio.h>
# include <string.h>
# include <iostream>
# include <algorithm>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

const int M = 1e6 + 10;

int mod;

bool vis[M];
int p[M], pn=0, inv[M];
int h[M];
int mu[M], phi[M];

inline int solve(int n, int m) {
  int res = 0;
  for (int i=1, lst=0; i<=n; i=lst+1) {
    lst = min(n/(n/i), m/(m/i));
    int t = h[lst] - h[i-1];
    if(t < 0) t += mod;
    res += 1ll * (n/i) * (m/i) % mod * t % mod;
    if(res >= mod) res -= mod;
  }
  return res;
}

int main() {
  int Test, n, m; cin >> Test;
  while(Test --) {
  	memset(vis, 0, sizeof vis);
  	memset(h, 0, sizeof h);
  	pn = 0;
  	
    cin >> n >> m >> mod;
    if(n > m) swap(n, m);
    
	inv[1] = 1;
    for (int i=2; i<=n; ++i) inv[i] = 1ll * (mod-mod/i) * inv[mod%i] % mod;
    
    mu[1] = phi[1] = 1;
    for (int i=2; i<=n; ++i) {
      if(!vis[i]) {
        p[++pn] = i;
        mu[i] = -1;
        phi[i] = i-1;
      }
      for (int j=1; j<=pn && i*p[j]<=n; ++j) {
        vis[i*p[j]] = 1;
        if(i%p[j] == 0) {
          mu[i*p[j]] = 0;
          phi[i*p[j]] = p[j] * phi[i];
          break;
        } else {
          mu[i*p[j]] = -mu[i];
          phi[i*p[j]] = phi[i] * (p[j]-1);
        }
      }
    }
    for (int i=1; i<=n; ++i) {
      int t = 1ll * i * inv[phi[i]] % mod;
      for (int j=i; j<=n; j+=i) {
        if(mu[j/i]) {
          if(mu[j/i] == 1) {
            h[j] += t;
            if(h[j] >= mod) h[j] -= mod;
          } else {
            h[j] -= t;
            if(h[j] < 0) h[j] += mod;
          }
        }
      }
    }
    for (int i=1; i<=n; ++i) {
      h[i] += h[i-1];
      if(h[i] >= mod) h[i] -= mod;
    }
    cout << solve(n, m) << endl;
  }
    
  return 0;
}

